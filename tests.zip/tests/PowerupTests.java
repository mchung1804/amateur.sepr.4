package com.kroy.tests;


import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.kroy.game.*;
import com.kroy.game.Powerups.*;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class PowerupTests {
    FireEngine testFireEngine;
    Patrol testPatrol;

    @Before
    /**
     * Function to set up values that will be used for testing
     */
    public void init(){
        testFireEngine = new FireEngine(50, 100, 10, 10, new Tile(), 10, 50, 100);
        testFireEngine.setTexture(Assets.fireEngineSpriteTexture);

        testPatrol = new Patrol(50, 100, 10, 10, new Tile());
    }


    @Test
    public void testAttackPowerUpEngine(){
        AttackPowerup attPowerup = new AttackPowerup();

        assertEquals(10, testFireEngine.getDamage());
        attPowerup.trigger(testFireEngine);
        assertEquals(15, testFireEngine.getDamage());
    }

    @Test
    public void testAttackPowerUpPatrol(){
        AttackPowerup attPowerup = new AttackPowerup();

        assertEquals(10, testPatrol.getDamage());
        attPowerup.trigger(testPatrol);
        assertEquals(10, testPatrol.getDamage());
    }

    @Test
    public void testRangePowerUpEngine(){
        RangePowerup attPowerup = new RangePowerup();

        assertEquals(10, testFireEngine.getRange());
        attPowerup.trigger(testFireEngine);
        assertEquals(11, testFireEngine.getRange());
    }

    @Test
    public void testRangePowerUpPatrol(){
        RangePowerup attPowerup = new RangePowerup();

        assertEquals(10, testPatrol.getRange());
        attPowerup.trigger(testPatrol);
        assertEquals(10, testPatrol.getRange());
    }

    @Test
    public void testRepairPowerUpEngine(){
        RepairPowerup attPowerup = new RepairPowerup();

        assertEquals(50, testFireEngine.getHealth());
        attPowerup.trigger(testFireEngine);
        assertEquals(90, testFireEngine.getHealth());
    }

    @Test
    public void testRepairPowerUpPatrol(){
        RepairPowerup attPowerup = new RepairPowerup();

        assertEquals(50, testPatrol.getHealth());
        attPowerup.trigger(testPatrol);
        assertEquals(50, testPatrol.getHealth());
    }

    @Test
    public void testSpeedPowerUpEngine(){
        SpeedPowerup attPowerup = new SpeedPowerup();

        assertEquals(10, testFireEngine.getSpeed());
        attPowerup.trigger(testFireEngine);
        assertEquals(11, testFireEngine.getSpeed());
    }

    @Test
    public void testWaterPowerUpEngine(){
        WaterPowerup attPowerup = new WaterPowerup();

        assertEquals(50, testFireEngine.getWaterAmount());
        attPowerup.trigger(testFireEngine);
        assertEquals(51, testFireEngine.getWaterAmount());
    }
}
