package com.kroy.tests;

import com.badlogic.gdx.graphics.Texture;
import com.kroy.game.*;
import org.junit.Test;

import java.util.HashMap;

import static org.junit.Assert.assertEquals;

public class TooltipTest {

    @Test
    public void testConstructor(){
        Tooltip testTooltip = new Tooltip("test", 6, 5, 4, 3);

        assertEquals("test", testTooltip.getName());
        assertEquals(6, testTooltip.getX());
        assertEquals(5, testTooltip.getY());
        assertEquals(4, testTooltip.getIconSize());
        assertEquals(3, testTooltip.getFontSpacing());
    }


    @Test
    public void testAddValue(){
        Tooltip testTooltip = new Tooltip("test", 6, 5, 4, 3);

        testTooltip.addValue("test string", 123, Assets.healthIconTexture);

        HashMap<String, Texture> textures = testTooltip.getTextures();
        HashMap<String, Texture> expectedTextures = new HashMap<>();
        expectedTextures.put("test string", Assets.healthIconTexture);

        HashMap<String, Object> values = testTooltip.getValues();
        HashMap<String, Object> expectedValues = new HashMap<>();
        expectedValues.put("test string", 123);

        assertEquals(expectedValues, values);
        assertEquals(expectedTextures, textures);
    }

    @Test
    public void testUpdateValue(){

        Tooltip testTooltip = new Tooltip("test", 6, 5, 4, 3);

        testTooltip.addValue("test string", 123, Assets.healthIconTexture);

        testTooltip.updateValue("test string", 321);

        HashMap<String, Object> values = testTooltip.getValues();
        HashMap<String, Object> expectedValues = new HashMap<>();
        expectedValues.put("test string", 321);

        assertEquals(expectedValues, values);
    }

}
