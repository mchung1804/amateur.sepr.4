package com.kroy.tests;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.GL30;
import com.badlogic.gdx.graphics.Texture;
import com.kroy.game.*;
import com.kroy.game.Character;
import com.kroy.game.Map;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import java.util.*;

import static org.junit.Assert.*;

@RunWith(GdxTestRunner.class)
public class EnemyTests {

    Enemy testEnemy;
    Map testMap;


    @Before
    public void init(){
        Gdx.gl20 = Mockito.mock(GL20.class);
        Gdx.gl30 = Mockito.mock(GL30.class);

        Assets.loadGameAssets();
        testEnemy = new Enemy(false, 1,1, Difficulty.DIFFICULTY_EASY);
        String directory = Gdx.files.getLocalStoragePath() + "assets/Data/yorkMapFlipped.csv";
        testMap = new Map(directory);
    }

    @Test
    public  void testConstructor(){
        assertFalse(testEnemy.isMyTurn());
        assertEquals(1, testEnemy.getAliveCharacters());
        assertEquals(1, testEnemy.getPatrols().size());
    }

    @Test
    public void testFortressConstructor(){
        Fortress testFortress = new Fortress(5, 10, 6, 7, new Tile(), "test string");

        assertEquals(5, testFortress.getHealth());
        assertEquals(10, testFortress.getMaxHealth());
        assertEquals(6, testFortress.getDamage());
        assertEquals(7, testFortress.getRange());
        assertEquals("test string", testFortress.getName());
    }

    @Test
    public void testCreateFortressEasy(){
        Fortress testFortress = testEnemy.createFortress("TEST_FORTRESS", 0,Difficulty.DIFFICULTY_EASY);
        assertEquals(11, testFortress.getHealth());
        assertEquals(3, testFortress.getDamage());
        assertEquals(5, testFortress.getRange());
    }

    @Test
    public void testCreateFortressMedium(){
        Fortress testFortress = testEnemy.createFortress("TEST_FORTRESS", 0,Difficulty.DIFFICULTY_MEDIUM);
        assertEquals(11, testFortress.getHealth());
        assertEquals(5, testFortress.getDamage());
        assertEquals(4, testFortress.getRange());
    }

    @Test
    public void testCreateFortressHard(){
        Fortress testFortress = testEnemy.createFortress("TEST_FORTRESS", 0,Difficulty.DIFFICULTY_HARD);
        assertEquals(11, testFortress.getHealth());
        assertEquals(1, testFortress.getDamage());
        assertEquals(6, testFortress.getRange());
    }

    @Test
    public void testCreatePatrolEasy(){
        Patrol testPatrol = testEnemy.createPatrol(0,Difficulty.DIFFICULTY_EASY);
        assertEquals(7, testPatrol.getHealth());
        assertEquals(5, testPatrol.getDamage());
        assertEquals(6, testPatrol.getRange());
    }

    @Test
    public void testCreatePatrolMedium(){
        Patrol testPatrol = testEnemy.createPatrol(0,Difficulty.DIFFICULTY_MEDIUM);
        assertEquals(8, testPatrol.getHealth());
        assertEquals(6, testPatrol.getDamage());
        assertEquals(7, testPatrol.getRange());
    }

    @Test
    public void testCreatePatrolHard(){
        Patrol testPatrol = testEnemy.createPatrol(0,Difficulty.DIFFICULTY_HARD);
        assertEquals(9, testPatrol.getHealth());
        assertEquals(7, testPatrol.getDamage());
        assertEquals(8, testPatrol.getRange());
    }

    @Test
    public void testCalculateTargets(){
        testEnemy = new Enemy(false, 6,1,Difficulty.DIFFICULTY_EASY);
        testEnemy.distributeTeamLocation(testMap.getFortressTiles());
        Human testHuman = new Human(false, 1,Difficulty.DIFFICULTY_EASY);
        testHuman.createFireEngine(0,Difficulty.DIFFICULTY_EASY);
        testHuman.distributeTeamLocation(testMap.getNClosest(1, testMap.getFortressTiles()[0], TileType.TILE_TYPES_ROAD));
        HashMap testLocations = testEnemy.calculateTargets(testMap);

        assertTrue(testLocations.containsValue(testHuman.getTeam().get(0).getLocation()));

    }

    @Test
    public void testDistributesPatrols(){
        testEnemy = new Enemy(false, 6,6,Difficulty.DIFFICULTY_EASY);
        ArrayList<Patrol> testPatrols = new ArrayList<Patrol>();
        testPatrols.add(new Patrol(1,1,1,new Tile(0,0)));
        testPatrols.add(new Patrol(1,1,1,new Tile(10,10)));
        testPatrols.add(new Patrol(1,1,1,new Tile(20,20)));
        testPatrols.add(new Patrol(1,1,1,new Tile(30,30)));
        testPatrols.add(new Patrol(1,1,1,new Tile(40,40)));
        testPatrols.add(new Patrol(1,1,1,new Tile(50,50)));
        testEnemy.setPatrols(testPatrols);

        testEnemy.distributePatrols(testMap);

        List<Patrol> patrols = testEnemy.getPatrols();
        assertEquals(3, patrols.get(0).getDirection());
        assertEquals(0, patrols.get(1).getDirection());
        assertEquals(3, patrols.get(2).getDirection());
        assertEquals(0, patrols.get(3).getDirection());
        assertEquals(2, patrols.get(4).getDirection());
        assertEquals(1, patrols.get(5).getDirection());
    }

    @Test
    public void testImproveFortress(){
        testEnemy.createFortress("TEST_FORTRESS", 0,Difficulty.DIFFICULTY_EASY);
        testEnemy.improveFortresses();
        Character testFortress = testEnemy.getTeam().get(0);
        assertEquals(13, testFortress.getHealth());
        assertEquals(4, testFortress.getDamage());
        assertEquals(5, testFortress.getRange());
    }

}
