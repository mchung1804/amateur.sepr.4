package com.kroy.tests;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.kroy.game.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;

import static org.junit.Assert.*;

public class StationTests {
    FireEngine testFireEngine;
    Station testStation;
    Tile testTile;
    ArrayList<Tile> tileList;

    @Before
    public void init(){
        testStation = new Station(2,4);
        testTile = new Tile();

        tileList = new ArrayList<>();
        tileList.add(testTile);

        testFireEngine = new FireEngine(50, 100, 10, 10, testTile, 10, 50, 100);
        testFireEngine.setTexture(Assets.fireEngineSpriteTexture);

        testTile.setInhabitant(testFireEngine);
    }

    @Test
    /**
     * Tests that the constructor of the station correctly assigns class variable values
     */
    public void testDefaultConstructor(){
        assertEquals(2, testStation.getMapX());
        assertEquals(4, testStation.getMapY());
        assertEquals("stationTile.png",testStation.getTexName());
        assertEquals(TileType.TILE_TYPES_STATION,testStation.getType());
        assertNull(testStation.getInhabitant());
    }

    @Test
    public void testRepair(){

        testStation.repairTiles(tileList);

        assertEquals(52, testFireEngine.getHealth());

    }

    @Test
    public void testRefill(){

        testStation.refillTiles(tileList);

        assertEquals(52, testFireEngine.getWaterAmount());

    }

    @Test
    public void testDestroy(){

        testStation.destroy();

        assertEquals("lavaTile.png", testStation.getTexName());

    }

}
